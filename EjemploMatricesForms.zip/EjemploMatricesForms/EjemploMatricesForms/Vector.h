#pragma once
#define FILAS 100
#define COLUMNAS 100

class Vector
{
private:
	int vec[FILAS][COLUMNAS];
	int fila;
	int columna;
	int tamanofilas;
	int tamanocolumnas;
	int grande;

public:
	Vector(void);
	~Vector(void);

	int Get_tamanofilas();
	void Set_tamanofilas(int tamfil);
	int Get_tamanocolumnas();
	void Set_tamanocolumnas(int tamcolum);

	int Get_vector(int fila, int columna);
	void Set_vector(int fila, int columna, int elemento);
	void incrementarFilas();
	void incrementaColumnas();
	void DecrementarFilas();
	void DecrementarColumnas();
	bool Vacio_vector();
	bool lleno_vector();
	bool Insertar(int fila, int columna, int elemento);
	void Formula();
	int Get_grande();
};

