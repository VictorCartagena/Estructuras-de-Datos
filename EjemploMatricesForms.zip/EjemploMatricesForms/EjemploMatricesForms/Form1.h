#pragma once
#include <iostream>
#include <string>
#include "Vector.h"
#include <msclr\marshal_cppstd.h>

namespace EjemploMatricesForms {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
    using namespace msclr::interop;

	//variable global
	Vector vectorsito;
	int posicionfila=0;
	int posicioncolumna=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtCantidadFilas;
	private: System::Windows::Forms::TextBox^  txtCantidadColumnas;
	private: System::Windows::Forms::TextBox^  txtValores;
	private: System::Windows::Forms::DataGridView^  Grilla;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtElementoGrande;
	private: System::Windows::Forms::Button^  btnCalcularElementoGrande;
	private: System::Windows::Forms::Button^  btnDefinirFilas;
	private: System::Windows::Forms::Button^  btnDefinirColumnas;
	private: System::Windows::Forms::Button^  btnIngresarValores;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtCantidadFilas = (gcnew System::Windows::Forms::TextBox());
			this->txtCantidadColumnas = (gcnew System::Windows::Forms::TextBox());
			this->txtValores = (gcnew System::Windows::Forms::TextBox());
			this->Grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtElementoGrande = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcularElementoGrande = (gcnew System::Windows::Forms::Button());
			this->btnDefinirFilas = (gcnew System::Windows::Forms::Button());
			this->btnDefinirColumnas = (gcnew System::Windows::Forms::Button());
			this->btnIngresarValores = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(23, 24);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(113, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Cantidad de filas";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(26, 55);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(148, 17);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Cantidad de columnas";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(26, 93);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(56, 17);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Valores";
			// 
			// txtCantidadFilas
			// 
			this->txtCantidadFilas->Location = System::Drawing::Point(190, 19);
			this->txtCantidadFilas->Name = L"txtCantidadFilas";
			this->txtCantidadFilas->Size = System::Drawing::Size(100, 22);
			this->txtCantidadFilas->TabIndex = 3;
			// 
			// txtCantidadColumnas
			// 
			this->txtCantidadColumnas->Location = System::Drawing::Point(190, 52);
			this->txtCantidadColumnas->Name = L"txtCantidadColumnas";
			this->txtCantidadColumnas->Size = System::Drawing::Size(100, 22);
			this->txtCantidadColumnas->TabIndex = 4;
			// 
			// txtValores
			// 
			this->txtValores->Location = System::Drawing::Point(190, 88);
			this->txtValores->Name = L"txtValores";
			this->txtValores->Size = System::Drawing::Size(100, 22);
			this->txtValores->TabIndex = 5;
			// 
			// Grilla
			// 
			this->Grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grilla->Location = System::Drawing::Point(29, 135);
			this->Grilla->Name = L"Grilla";
			this->Grilla->RowTemplate->Height = 24;
			this->Grilla->Size = System::Drawing::Size(573, 242);
			this->Grilla->TabIndex = 6;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Valores";
			this->Column1->Name = L"Column1";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(29, 400);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(161, 17);
			this->label4->TabIndex = 7;
			this->label4->Text = L"El elemento mas grande";
			// 
			// txtElementoGrande
			// 
			this->txtElementoGrande->Location = System::Drawing::Point(219, 400);
			this->txtElementoGrande->Name = L"txtElementoGrande";
			this->txtElementoGrande->Size = System::Drawing::Size(100, 22);
			this->txtElementoGrande->TabIndex = 8;
			// 
			// btnCalcularElementoGrande
			// 
			this->btnCalcularElementoGrande->Location = System::Drawing::Point(383, 398);
			this->btnCalcularElementoGrande->Name = L"btnCalcularElementoGrande";
			this->btnCalcularElementoGrande->Size = System::Drawing::Size(75, 23);
			this->btnCalcularElementoGrande->TabIndex = 9;
			this->btnCalcularElementoGrande->Text = L"Calcular";
			this->btnCalcularElementoGrande->UseVisualStyleBackColor = true;
			this->btnCalcularElementoGrande->Click += gcnew System::EventHandler(this, &Form1::btnCalcularElementoGrande_Click);
			// 
			// btnDefinirFilas
			// 
			this->btnDefinirFilas->Location = System::Drawing::Point(329, 18);
			this->btnDefinirFilas->Name = L"btnDefinirFilas";
			this->btnDefinirFilas->Size = System::Drawing::Size(75, 23);
			this->btnDefinirFilas->TabIndex = 10;
			this->btnDefinirFilas->Text = L"Definir";
			this->btnDefinirFilas->UseVisualStyleBackColor = true;
			this->btnDefinirFilas->Click += gcnew System::EventHandler(this, &Form1::btnDefinirFilas_Click);
			// 
			// btnDefinirColumnas
			// 
			this->btnDefinirColumnas->Location = System::Drawing::Point(329, 52);
			this->btnDefinirColumnas->Name = L"btnDefinirColumnas";
			this->btnDefinirColumnas->Size = System::Drawing::Size(75, 23);
			this->btnDefinirColumnas->TabIndex = 11;
			this->btnDefinirColumnas->Text = L"Definir";
			this->btnDefinirColumnas->UseVisualStyleBackColor = true;
			this->btnDefinirColumnas->Click += gcnew System::EventHandler(this, &Form1::btnDefinirColumnas_Click);
			// 
			// btnIngresarValores
			// 
			this->btnIngresarValores->Location = System::Drawing::Point(329, 90);
			this->btnIngresarValores->Name = L"btnIngresarValores";
			this->btnIngresarValores->Size = System::Drawing::Size(75, 23);
			this->btnIngresarValores->TabIndex = 12;
			this->btnIngresarValores->Text = L"Ingresar";
			this->btnIngresarValores->UseVisualStyleBackColor = true;
			this->btnIngresarValores->Click += gcnew System::EventHandler(this, &Form1::btnIngresarValores_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(635, 447);
			this->Controls->Add(this->btnIngresarValores);
			this->Controls->Add(this->btnDefinirColumnas);
			this->Controls->Add(this->btnDefinirFilas);
			this->Controls->Add(this->btnCalcularElementoGrande);
			this->Controls->Add(this->txtElementoGrande);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->Grilla);
			this->Controls->Add(this->txtValores);
			this->Controls->Add(this->txtCantidadColumnas);
			this->Controls->Add(this->txtCantidadFilas);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinirFilas_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tamfil=System::Convert::ToInt32(txtCantidadFilas->Text);
			 vectorsito.Set_tamanofilas(tamfil);
			 Grilla->RowCount=vectorsito.Get_tamanofilas();
			 posicionfila=0;
			 posicioncolumna=0;
			 }
private: System::Void btnDefinirColumnas_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tamcolum=System::Convert::ToInt32(txtCantidadColumnas->Text);
			 vectorsito.Set_tamanocolumnas(tamcolum);
			 Grilla->ColumnCount=vectorsito.Get_tamanocolumnas();
			 posicionfila=0;
			 posicioncolumna=0;
		 }
private: System::Void btnIngresarValores_Click(System::Object^  sender, System::EventArgs^  e) {
			int elemento;
			 elemento=System::Convert::ToInt32(txtValores->Text);
			 if(vectorsito.Insertar(posicionfila,posicioncolumna,elemento))
			 {
				 if(posicioncolumna>=vectorsito.Get_tamanocolumnas())
				 {
					 posicioncolumna=0;
					 posicionfila++;
				 }
					 Grilla->Rows[posicionfila]->Cells[posicioncolumna]->Value=elemento;
					 posicioncolumna++;
				 //Grilla->Rows[posicionfila]->Cells[posicioncolumna]->Value=elemento;
			 }
		 }
private: System::Void btnCalcularElementoGrande_Click(System::Object^  sender, System::EventArgs^  e) {
			 vectorsito.Formula();
			 txtElementoGrande->Text=System::Convert::ToString(vectorsito.Get_grande());
		 }
};
}

