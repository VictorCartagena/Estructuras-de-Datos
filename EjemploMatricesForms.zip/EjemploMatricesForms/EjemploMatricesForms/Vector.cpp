#include "StdAfx.h"
#include "Vector.h"
#include <iostream>
#define FILAS 100
#define COLUMNAS 100

using namespace std;

Vector::Vector(void)
{
	vec[FILAS][COLUMNAS]=0;
	grande=0;
}

Vector::~Vector(void)  //destructor
{
}

int Vector::Get_tamanofilas()
{
	return tamanofilas;
}

void Vector::Set_tamanofilas(int tamfil)
{
	tamanofilas=tamfil;
}

int Vector::Get_tamanocolumnas()
{
	return tamanocolumnas;
}

void Vector::Set_tamanocolumnas(int tamcolum)
{
	tamanocolumnas=tamcolum;
}

int Vector::Get_vector(int fila, int columna)  //agarrando contenido
{
	return vec[fila][columna];
}

void Vector::Set_vector(int fila, int columna, int elemento)    //dandole valores a ese espacio
{
	vec[fila][columna]=elemento;
}

void Vector::incrementarFilas()
{
	tamanofilas++;
}

void Vector::incrementaColumnas()
{
	tamanocolumnas++;
}

void Vector::DecrementarFilas()
{
	tamanofilas--;
}

void Vector::DecrementarColumnas()
{
	tamanocolumnas--;
}

bool Vector::Vacio_vector()
{
	if((tamanofilas==0)&&(tamanocolumnas==0))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Vector::lleno_vector()
{
	if((tamanofilas==(FILAS-1))&&(tamanocolumnas==(COLUMNAS-1)))
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Vector::Insertar(int fila, int columna, int elemento)
{
	if(fila<0 || columna<0 || fila>tamanofilas || columna>tamanocolumnas)
	{
		return false;
	}
	else
	{
		if(lleno_vector()==true)
		{
			return false;
		}
		else
		{
			int i=Get_tamanofilas();
			int j=Get_tamanocolumnas();
			while((i>fila)&&(j>columna))
			{
				vec[i][j]=vec[i-1][j-1];
				i--;
				j--;
			}
			vec[fila][columna]=elemento;
			return true;
		}
	}
}

void Vector::Formula()
{
	grande=vec[0][0];

	for(int fila=0;fila<tamanofilas; fila++)
	{	
		for(int columna=0;columna<tamanocolumnas; columna++)
		 {
		 if(grande<vec[fila][columna])
		 grande = vec[fila][columna];
		 }
	}
}

int Vector::Get_grande()
{
	return grande;
}