#pragma once
#include "Dato.h"

class Nodo
{
public:
	Dato datito;
	Nodo *anterior;

	Nodo(void);
	~Nodo(void);

	void Apilar(Nodo *&frente, Nodo *&final);
	void MostrarPila();
};

