#pragma once
#include <string>

using namespace std;

class Dato
{
public:
	string Nombre;
	string Carrera;
	double Codigo;
	Dato()
	{
		Codigo=0;
		Nombre="Unknown";
		Carrera="Unknown";
	}
	~Dato(void);
};