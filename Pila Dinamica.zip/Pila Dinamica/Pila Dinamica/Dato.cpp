#include "StdAfx.h"
#include "Dato.h"


Dato::~Dato(void)
	{
	}
