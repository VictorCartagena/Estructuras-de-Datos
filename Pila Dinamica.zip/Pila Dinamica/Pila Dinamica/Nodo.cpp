#include "StdAfx.h"
#include "Nodo.h"
#include <iostream>

using namespace std;

Nodo::Nodo(void)
{
	anterior=NULL;
}

Nodo::~Nodo(void)
{
}

void Nodo::Apilar(Nodo *&frente, Nodo *&final)
{
	Nodo *elemento=new Nodo;
	if(frente==NULL)
	{
		frente=final=elemento;
		cout<<"Nombre: ";
		cin>>elemento->datito.Nombre;
		cout<<"Codigo: ";
		cin>>elemento->datito.Codigo;
		cout<<"Carrera: ";
		cin>>elemento->datito.Carrera;
		cout<<endl;
	}
	else
	{
		elemento->anterior=final;
		final=elemento;
		cout<<"Nombre: ";
		cin>>elemento->datito.Nombre;
		cout<<"Codigo: ";
		cin>>elemento->datito.Codigo;
		cout<<"Carrera: ";
		cin>>elemento->datito.Carrera;
		cout<<endl;
	}
}
void Nodo::MostrarPila()
{
	cout<<"("<<datito.Codigo<<"="<<datito.Nombre<<")";
	if(anterior!=NULL)
	{
	cout<<" <- ";
		anterior->MostrarPila();
	}
	else
	{
		cout<<endl;
	}
}
