// Pila Dinamica.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Nodo.h"

using namespace std;

void Desapilar(Nodo *&final);

void main()
{
	Nodo *frente=NULL;
	Nodo *final=NULL;
	int opc=-1;
	do
	{
		cout<<"0.Salir"<<endl;
		cout<<"1.La Pila esta vacia?"<<endl;
		cout<<"2.Apilar"<<endl;
		cout<<"3.Desapilar"<<endl;
		cout<<"4.Mostrar Nodos"<<endl;
		cout<<"OPCION:  "; 
		cin>>opc;
		switch (opc)
		{
		case 1:
		if(frente==NULL)
		{
			cout<<"La pila se encuentra vacia"<<endl;
			cout<<endl;
		}
		else
		{
			cout<<"Se encuentran elemento(s) en la pila"<<endl;
		}
		break;
		case 2:
			frente->Apilar(frente,final);
		break;
		case 3:
			Desapilar(final);
			break;
		case 4:
			if(final!=NULL)
			{
			final->MostrarPila();
			}
			else
			{
				cout<<"La pila esta vacia"<<endl;
			}
		break;
		}
	}
	while(opc!=0);
}

void Desapilar(Nodo *&final)
{
	if(final!=NULL)
	{
	cout<<"Nombre: "<<final->datito.Nombre<<endl;
	cout<<"Codigo: "<<final->datito.Codigo<<endl;
	cout<<"Carrera: "<<final->datito.Carrera<<endl;
	final=final->anterior;
	}
	else
	{
		cout<<"la pila esta vacia"<<endl;
	}
}

