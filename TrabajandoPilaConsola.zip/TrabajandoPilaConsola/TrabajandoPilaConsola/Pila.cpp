#include "StdAfx.h"
#include "Pila.h"
#include <iostream>

#define MAX 10

using namespace std;

Pila::Pila(void)
{
	pila[MAX]=0;
	tope=-1;
	//n=0;
}

Pila::~Pila(void)
{
}

int Pila::gettope()
{
	return tope;
}

bool Pila::Apilar(int elemento)
{
	if(pilallena(tope)==true) //metodo pila llena
	{
		cout<<"Desbordamiento de pila"<<endl;
		return false;
	}
	else
	{
		tope++;
		pila[tope]=elemento;
		return true;
	}
}

bool Pila::PilaVacia()
{
	if (tope==-1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Pila::pilallena(int tope)
{
	if(tope==(MAX-1))
	{
		return true;
	}
	return false;
}

void Pila::verpila()
{
	for(int i=0; i<=tope; i++)
	{
		cout<<pila[i]<<endl;
	}
}

bool Pila::Desapilar()
{
	bool res;
	if(PilaVacia()==true)
	{
		res=false;
	}
	else
	{
		tope--;
		res=true;
	}
	return res;
}

int Pila::ValorTope()
{
	return pila[gettope()];
}

void Pila::OrdenarPilaAscendente()
{
	int aux;
	for(int i=1; i<tope; i++)
	{
		for(int j=0; j<=tope-1; j++)
		{
			if(pila[j]>pila[j+1])
			{
				aux=pila[j];
				pila[j]=pila[j+1];
				pila[j+1]=aux;
			}
		}
	}
}

void Pila::OrdenarPilaDescendente()
{
	int aux;
	for(int i=1; i<tope; i++)
	{
		for(int j=0; j<tope-1; j++)
		{
			if(pila[j]<pila[j+1])
			{
				aux=pila[j];
				pila[j]=pila[j+1];
				pila[j+1]=aux;
			}
		}
	}
}

void Pila::EliminarRepetidos()
{
	int pilafinal[MAX];
	int a=0;

	for(int i=0; i<tope; i++)
	{
		//Parte de la funcion "siexistepila"
		bool siexistepila =false;
		//recorremos la pilafinal, es decir la pila sin los numeros repetidos
		for(int j=0; j<tope; j++)
		{
			//si el elemento i de la pilaoriginal es igual a cualquiera que 
			//tenga la pilafinal, significa que ese elemento i, ya existe
			//por lo tanto esta repetido
			if(pilafinal[j]==pila[i])
			{
				//si esta repetido
				siexistepila= true;
				//rompemos el bucle de "j" en cuanto se encuentre el repetido
				break;
			}
		}
		//si no existe el elemento i de la pila original entonces lo
		//metemos en la pila final
		if(siexistepila==false)
			{
				pilafinal[a]=pila[i];
				a++;
			}
	}
	for(int i=0;i<a;i++)
	{
		cout<<pilafinal[i]<<endl;
	}
}
