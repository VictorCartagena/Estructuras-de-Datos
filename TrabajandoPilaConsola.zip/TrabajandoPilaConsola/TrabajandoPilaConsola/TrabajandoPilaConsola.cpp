// TrabajandoPilaConsola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Pila.h"
#include <iostream>
#include "conio.h"

using namespace std;

void main()
{
	//int n;
	int op;
	int elem;
	Pila pilita;

	//do
	//{
	//	cout<<"ingrese el tama�o de la pila:"<<endl;
	//	cin>>n;
	//}
	//while((n>MAX) || (n<=0));
	do
	{
		cout<<"------------- MENU -------------"<<endl;
		cout<<"|1.- Apilar                     |"<<endl;
		cout<<"|2.- Mostrar Pila               |"<<endl;
		cout<<"|3.- Desapilar                  |"<<endl;
		cout<<"|4.- Ordenar en Ascendente      |"<<endl;
		cout<<"|5.- Ordenar en Descendente     |"<<endl;
		cout<<"|6.- Eliminar Numeros Repetidos |"<<endl;
		cout<<"|0.- Salir                      |"<<endl;
		cout<<"--------------------------------"<<endl;
		cout<<"elija una opcion: ";
		cin>>op;
		switch(op)
		{
			case 1:
				cout<<"introduzca valor:";
				cin>>elem;
				pilita.Apilar(elem);
				break;
			case 2:
				cout<<" "<<endl;
				pilita.verpila();
				break;
			case 3:
				cout<<"desapilado"<<endl;
				pilita.Desapilar();
				pilita.verpila();
				break;
			case 4:
				pilita.OrdenarPilaAscendente();
				//pilita.verpila();
				break;
			case 5:
				pilita.OrdenarPilaDescendente();
				pilita.verpila();
				break;
			case 6:
				pilita.EliminarRepetidos();
				break;
		}
	}
	while(op>0);
}

