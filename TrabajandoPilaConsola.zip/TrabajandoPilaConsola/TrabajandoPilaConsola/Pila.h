#pragma once

#define MAX 10

class Pila
{
private:
	int pila[MAX];
	int tope;
	//int n;

public:
	Pila(void);
	~Pila(void);

	int gettope();  //para saber la posicion del ultimo incresado
	bool Apilar(int elemento);
	bool PilaVacia();
	bool pilallena(int tope);
	void verpila();
	bool Desapilar();
	int ValorTope();  //para saber el valor establecido en esa posicion
	void OrdenarPilaAscendente();
	void OrdenarPilaDescendente();
	void EliminarRepetidos();
};

